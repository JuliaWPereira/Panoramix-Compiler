/**********************************************
 *
 *   Panoramix Compiler 
 *   - Abstract Syntax Tree header
 *    
 *   @version 1.1
 *   @edited November 29, 2019
 *   @author Júlia Wotzasek Pereira
 *
**********************************************/

#ifndef _AST_H_
#define _AST_H_

/*
 * Declarations for a C- compiler. Here we
 * define the requiered structures and necessary
 * functions to create the Abstract Syntax Tree
 * and the Symbol Table of the Program
*/

/* interface with the panoramix lexer */
extern int yylineno;

/* @function: yyerror 
 * 
 * procedure that communicates an error with lexer
 * 
 * @param {char*} the symbol name
 * @param {...} multiple parameters
 *
 * @returns void
*/

void yyerror(char *s, ...);


/* Function and procedure prototypes for the symtab */

/* Symbol table */

/* struct symbol: This structure receive the name, the
 * value, which function it belongs and its 
 * arguments. The symlist can be a NULL pointer, if
 * it don't have arguments.
*/

struct symbol { 
	char *name;
	int value;
	int type; /* int or void */
	int isArray; /* not an array by default */
	int length;
	struct symbol *father; /* it is not null if it is an indexed symbol */
	struct ast *func; /* statements for the function */
	struct symlist *syms; /* list of arguments */
};

struct symbol* createsymbol(char* symname);

/* struct symlist: This structure is a linked-list 
 * of symbols, for an argument list.
*/

struct symlist {
	struct symbol *sym;
	struct symlist *next;
};

/* Definition of a simple symtab of fixed size */
#define NHASH 9997
struct symbol symtab[NHASH];

/* Function and procedure prototypes for the symtab */

/* @function: lookup 
 * 
 * alocates or find a position at the symbol table
 * for a new symbol.
 * 
 * @param {char*} the identifier name
 *
 * @returns {symbol*}: pointer to a symbol at the table
*/

struct symbol* lookup(char* symname);

/* @function: newsymlist 
 * 
 * creates a list of simbles.
 * 
 * @param {struct symbol*} sym : symbol added
 * @param {struct symlist*} pointer to a symlist.
 *
 * @returns {struct symlist*}
*/

struct symlist *newsymlist(struct symbol* sym, struct symlist *next);

/* @function: symlistfree 
 * 
 * Free the alocated memory of the symlist passed.
 * 
 * @param {struct symlist*} pointer to a symlist.
 *
 * @returns: void
*/

void symlistfree(struct symlist *s1);

/* Abstract Syntax Tree */

/* Node types: We have defined a lot of node types
 * for the AST. There are the possible types:
 *
 * Simple operations: + - = * /
 * Comparisions: 1-7 possibilities > >= < <= == !=
 * L expression or statement list
 * F - user function call
 * I - if-else statement
 * W - while statement
 * K - constant value
 * N - symbol reference
 * = - assigment node.
*/

/* Basic node for an AST */
struct ast {
	int nodetype;
	struct ast *left;
	struct ast *right;
};

typedef struct ast tree;

struct fndef {
	int nodetype; /* type F */
	struct ast* params;
	struct ast* body;
	struct symbol *sym;
	int ret; /*return */
};

/* Node for call a created function */
struct fncall {
	int nodetype; /* type C */
	struct ast *args; /* list of arguments */
	struct symbol *sym;
};

/* Node to flow statements, as IF-ELSE WHILE */
struct flow {
	int nodetype; /* type I or W */
	struct ast *condition;
	struct ast *then_list; /* then branch */
	struct ast *else_list; /*optional else branch */
};

/* Node for integer numbers */
struct numval {
	int nodetype; /* type K */
	int number;
};

/* Node for a symbol reference */
struct symref {
	int nodetype; /* type N */
	struct symbol *sym;
	struct ast* index;
};

/* Node for an assigment */
struct symasgn {
	int nodetype; /* type = */
	struct symref *symref;
	struct ast *value;
};

/* Function prototypes to build an AST */

/* @function: newast 
 * 
 * creates a generic abstract syntax tree pointer.
 * 
 * @param {int} nodetype : which type of node
 * @param {struct ast*} l: left child
 * @param {struct ast*} r: right child
 *
 * @returns {struct ast*} new AST pointer.
*/

struct ast* newast(int nodetype, struct ast* l, struct ast* r);

/* @function: newcmp
 * 
 * creates a abstract syntax tree pointer for a
 * comparision statement.
 * 
 * @param {int} cmptype: which type of comparision
 * @param {struct ast*} l: left child
 * @param {struct ast*} r: right child
 *
 * @returns {struct ast*}
*/

struct ast* newcmp(int cmptype, struct ast* l, struct ast* r);

/* @function: newcall
 * 
 * makes a call to an user created function.
 * 
 * @param {struct symbol*} s : which function
 * @param {struct ast*} l: arguments of the function
 *
 * @returns {struct ast*} node of type fncall
*/

struct ast* newcall(struct symbol *s, struct ast *l);


/* @function: newref
 * 
 * creates a new reference for an identifier
 * 
 * @param {struct symbol*} s : symbol name
 * @param {int} type : type of the variable
 *
 * @returns {struct ast*} pointer to the symbol
*/

struct ast* newref(struct symbol *s, struct ast* type, struct ast *index);

/* @function: newasgn
 * 
 * makes the assigning of a value into a variable
 * 
 * @param {struct symbol*} s : symbol name
 * @param {struct ast*} v: AST of the calculated
 * value;
 *
 * @returns {struct ast*} pointer to the variable
*/

struct ast* newasgn(struct ast *s, struct ast *v);

/* @function: newnum
 * 
 * creates a node typed as 'K' to receive a number.
 * 
 * @param {int} i : integer value
 * 
 * @returns {struct ast*} pointer to the node.
*/

struct ast* newnum(int i);

/* @function: newflow
 * 
 * creates a abstract syntax tree pointer for a
 * flow like IF-ELSE or WHILE.
 * 
 * @param {int} nodetype: which type of flow
 * @param {struct ast*} cond: expression to be
 * tested.
 * @param {struct ast*} tl: then-list pointer
 * @param {struct ast*} el: else-list pointer
 *
 * @returns {struct ast*}
*/

struct ast* newflow(int nodetype, struct ast *cond, struct ast *tl, struct ast *el);

/* @function: dodef
 * 
 * define a new function. If the function is already defined,
 * it overrides the function declaration.
 * 
 * @param {struct symbol*} name: name of the new function.
 * @param {struct ast*} sysm: arguments of the function.
 * @param {struct ast*} func: statements of the function.
 *
 * @returns void
*/

void dodef(struct symbol *name, struct symlist *syms, struct ast *func);

/* @function: eval
 * 
 * evaluates the value of a AST.
 * 
 * @param {struct ast*} ast: which tree.
 *
 * @returns {int} evaluated value.
*/

int eval(struct ast *ast);

/* @function: astfree 
 * 
 * Free the alocated memory of the ast passed.
 * 
 * @param {struct ast*} ast
 *
 * @returns: void
*/

void treefree(struct ast *ast);

struct symbol* getSymbol(struct symbol *s, int index);

void printtree(struct ast *ast);

struct ast* newfn(struct ast* ret, struct symbol *name, struct ast *syms, struct ast* func);

struct ast* newtype(int type);

#endif