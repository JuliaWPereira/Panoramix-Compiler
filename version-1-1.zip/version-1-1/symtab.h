/**********************************************
 *
 *	 Panoramix Compiler - symtab.h
 *   
 *   @version 1.0
 *   @edited November 27, 2019
 *   @author Júlia Wotzasek Pereira
 *
**********************************************/
#ifndef _SYMTAB_H_
#define _SYMTAB_H_

/* The Symbol Table */

typedef enum {INT_TYPE,VOID_TYPE} ValueType;
typedef enum {FUNCTION,VARIABLE} ModeType;

struct symbol{ /* a word */
	char *name;
	struct ref *reflist;
};

struct ref{
	struct ref *next;
	ValueType vType;
	ModeType mType;
	char *scope;
	int lineno;
};

/* simple symtab of fixed size */
 #define NHASH 9997
 struct symbol symtab[NHASH];
 struct symbol *lookup(char*);
 void addref(int, char*);
 void printrefs();
#endif