/**********************************************
 *
 *	 Panoramix Compiler - Globals.h
 *   
 *   @version 1.0
 *   @edited November 27, 2019
 *   @author Júlia Wotzasek Pereira
 *
**********************************************/
#ifndef _GLOBALS_H_
#define _GLOBALS_H_

/* Token defintions */
typedef enum{
    /* book-keeping tokens */
    END,ERROR,
    /* reserved words */
    ELSE,IF,INT,RETURN,VOID,WHILE,
    /* multicharacter tokens */
    ID,NUM,
    /* special symbols */
    PLUS,MINUS,TIMES,OVER,LT,LEQ,GT,GEQ,EQ,NEQ,
    ASSIGN,SEMI,COLON,LPAREN,RPAREN,LBRACKET,
    RBRACKET,LBRACE,RBRACE
} TokenType;

 #endif