/**********************************************
 *
 *   Panoramix Compiler 
 *   - Abstract Syntax Tree Functions
 *    
 *   @version 1.1
 *   @edited November 29, 2019
 *   @author Júlia Wotzasek Pereira
 *
**********************************************/

/* requuired packages */
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h> /* to accept variable number of arguments */
#include <string.h>
#include "AST.h" /* header of this file */

/* Interface with the lexer */

/* @function: yyerror 
 * 
 * procedure that communicates an error with lexer
 * 
 * @param {char*} the symbol name
 * @param {...} multiple parameters
 *
 * @returns void
*/

void yyerror(char *s, ...)
{
	va_list ap;
	va_start(ap,s);
	fprintf(stderr, "%d: error: ", yylineno);
	vfprintf(stderr,s,ap);
	fprintf(stderr, "\n");
}

/* Symble Table */

/* Function and procedure for the symtab */

/* @function: symhash 
 * @static
 * @private
 * 
 * hash function to define the position of a symbol.
 * It uses the division method for hashing.
 *
 * @param {char*} sym: the symbol name.
 *
 * @returns {unsigned int}: the evaluated hash number.
*/

static unsigned symhash(char *sym)
{
	unsigned int hash = 0;
	unsigned c;

	/* basic hash function: 9 times the previous
	 * value XOR the new character.
	*/
	while(c = *sym++) hash = hash * 9 ^ c;

	return hash;
}

/* @function: lookup 
 * 
 * alocates or find a position at the symbol table
 * for a new symbol.
 * 
 * @param {char*} symname the identifier name
 *
 * @returns {symbol*}: pointer to a symbol at the table
 *
 * @todo : We should change the symtable implementation
 * to deal with colisions. Implement a chaining hashtable.
*/

struct symbol* createsymbol(char* symname)
{
	struct symbol *sym;
	sym = (struct symbol*)malloc(sizeof(struct symbol));
	if(sym)
	{
		sym->name = strdup(symname);
		sym->value = 0;
		sym->type = 259;
		sym->isArray = 0;
		sym->length = 0;
		sym->father = NULL;
		sym->func = NULL;
		sym->syms = NULL;
	}
	return sym;
}

struct symbol* lookup(char* symname)
{
	struct symbol *sp = &symtab[symhash(symname)%NHASH];
	int scount = NHASH; /* how many have we looked at */

	while(--scount >= 0)
	{
		if(sp->name && !strcmp(sp->name, symname))
		{
			return sp;
		}
		if(!sp->name) /* new entry - null pointer */
		{
			sp->name = strdup(symname);
			sp->value = 0;
			sp->type  = 0;
			sp->isArray = 0;
			sp->func = NULL;
			sp->syms = NULL;
			return sp;
		}
		if(++sp >= symtab+NHASH) sp = symtab; /*try the next entry */
	}
	yyerror("symbol table overflow\n");
	abort(); /* tried them all, table is full */
}

/* @function: newsymlist 
 * 
 * creates a list of simbles.
 * 
 * @param {struct symbol*} sym : symbol added
 * @param {struct symlist*} pointer to a symlist.
 *
 * @returns {struct symlist*}
*/

struct symlist* newsymlist(struct symbol *sym, struct symlist *next)
{
	struct symlist *sl = malloc(sizeof(struct symlist));

 	if(!sl) /* NULL pointer */ 
	{
		yyerror("out of space");
		exit(0);
	}
	sl->sym = sym;
	sl->next = next; /* add a new node at symlist */
	return sl;
}

/* @function: symlistfree 
 * 
 * Free the alocated memory of the symlist passed.
 * 
 * @param {struct symlist*} pointer to a symlist.
 *
 * @returns: void
*/

void symlistfree(struct symlist *sl)
{
	struct symlist *next_sl;
	while(sl) { /* not a NULL pointer */
		next_sl = sl->next;
		free(sl);
		sl = next_sl;
	}
}

/* Abstract Syntax Tree */

/* Node types: We have defined a lot of node types
 * for the AST. There are the possible types:
 *
 * Simple operations: + - = * /
 * Comparisions: 1-7 possibilities > >= < <= == !=
 * L expression or statement list
 * F - user function call
 * I - if-else statement
 * W - while statement
 * K - constant value
 * N - symbol reference
 * = - assigment node.
*/

/* @function: newast 
 * 
 * creates a generic abstract syntax tree pointer.
 * 
 * @param {int} nodetype : which type of node
 * @param {struct ast*} l: left child
 * @param {struct ast*} r: right child
 *
 * @returns {struct ast*} new AST pointer.
*/

struct ast* newast(int nodetype, struct ast* l, struct ast* r)
{
	/* make a usual ast pointer */
	struct ast *a = malloc(sizeof(struct ast));
	if(!a) /* NULL pointer */
	{
		yyerror("out of space");
		exit(0);
	}
	a->nodetype = nodetype;
	a->left = l;
	a->right = r;
	return a;
}

/* @function: newcmp
 * 
 * creates a abstract syntax tree pointer for a
 * comparision statement.
 * 
 * @param {int} cmptype: which type of comparision
 * @param {struct ast*} l: left child
 * @param {struct ast*} r: right child
 *
 * @returns {struct ast*}
*/

struct ast* newcmp(int cmptype, struct ast *l, struct ast *r)
{
	/* comparision uses normal ast node */
	struct ast *a = malloc(sizeof(struct ast));
	if(!a) /* NULL pointer */
	{
		yyerror("out of space");
		exit(0);
	}
	a->nodetype = '0' + cmptype; /* which comparision */
	a->left = l; 
	a->right = r;
	return a;
}

/* @function: newcall
 * 
 * makes a call to an user created function.
 * 
 * @param {struct symbol*} s : which function
 * @param {struct ast*} l: arguments of the function
 *
 * @returns {struct ast*} node of type fncall
*/

struct ast* newcall(struct symbol *s, struct ast *l)
{
	/* alocate a pointer to fncall node type */
	struct fncall *a = malloc(sizeof(struct fncall));
	if(!a) /* NULL pointer */
	{
		yyerror("out of space");
		exit(0);
	}
	a->nodetype = 'C'; /* note type for CALL */
	a->args = l; /* arguments */
	a->sym = s; /* which function */
	/* Cast the pointer to a ast pointer. It allows
	 * to build the AST properly.
	*/
	return (struct ast*)a;
}

/* @function: newref
 * 
 * creates a new reference for an identifier
 * 
 * @param {struct symbol*} s : symbol name
 *
 * @returns {struct ast*} pointer to the symbol
*/

struct ast* newref(struct symbol *s, struct ast* type, struct ast* index)
{
	/* allocate a symref node */
	struct symref *a = malloc(sizeof(struct symref));
	if(!a) /* pointer is NULL */
	{
		yyerror("out of space");
		exit(0);
	}
	a->nodetype = 'N'; /* node type for references */
	a->sym = s;
	a->sym->type = (type == NULL)? 259 : type->nodetype;
	a->index = index;
	return (struct ast*)a; /* casting to ast */
}

/* @function: newasgn
 * 
 * makes the assigning of a value into a variable
 * 
 * @param {struct symbol*} s : symbol name
 * @param {struct ast*} v: AST of the calculated
 * value;
 *
 * @returns {struct ast*} pointer to the variable
*/

struct ast* newasgn(struct ast *s, struct ast *v)
{
	/* alocate memory for a new symasgn */
	struct symasgn *a = malloc(sizeof(struct symasgn));
	if(!a) /* NULL pointer */
	{
		yyerror("out of space");
		exit(0);
	}
	a->nodetype = '='; /* node type for assigning */ 
	a->symref = (struct symref*)s;
	a->value = v;
	return (struct ast*)a; /* casting to ast pointer */
}

/* @function: newnum
 * 
 * creates a node typed as 'K' to receive a number.
 * 
 * @param {int} i : integer value
 * 
 * @returns {struct ast*} pointer to the node.
*/

struct ast* newnum(int i)
{
	/* creates a numval node */
	struct numval *a = malloc(sizeof(struct numval));
	if(!a) /* NULL pointer */
	{
		yyerror("out of space");
		exit(0);
	}
	a->nodetype = 'K'; /* node type for constants */
	a->number = i;
	return (struct ast*)a; /* casting to ast pointer */
}

/* @function: newflow
 * 
 * creates a abstract syntax tree pointer for a
 * flow like IF-ELSE or WHILE.
 * 
 * @param {int} nodetype: which type of flow
 * @param {struct ast*} cond: expression to be
 * tested.
 * @param {struct ast*} tl: then-list pointer
 * @param {struct ast*} el: else-list pointer
 *
 * @returns {struct ast*}
*/

struct ast* newflow(int nodetype, struct ast *cond, struct ast *tl, struct ast *el)
{
	/* creates a flow node */
	struct flow *a = malloc(sizeof(struct flow));
	if(!a) { /* NULL pointer */
		yyerror("out of space");
		exit(0);
	}
	a->nodetype = nodetype; /* I or W */
	a->condition = cond; /* expression evaluated */
	a->then_list = tl; /* then-list of statements */
	a->else_list = el; /* else-list of statements */
	return (struct ast *)a; /* casting to ast pointer */
}

/* @function: dodef
 * 
 * define a new function. If the function is already defined,
 * it overrides the function declaration.
 * 
 * @param {struct symbol*} name: name of the new function.
 * @param {struct ast*} sysm: arguments of the function.
 * @param {struct ast*} func: statements of the function.
 *
 * @returns void
*/

/*void dodef(struct symbol *name, struct symlist *syms, struct ast *func)
{
	if(name->syms) symlistfree(name->syms);
	if(name->func) treefree(name->func);
	name->syms = syms;
	name->func = func;
}*/

struct ast* newfn(struct ast* ret, struct symbol *name, struct ast *syms, struct ast *func)
{
	struct fndef *fd;
	fd = (struct fndef*)malloc(sizeof(struct fndef));			
	if(!fd) { /* NULL pointer */
		yyerror("out of space");
		exit(0);
	}
	fd->nodetype = 'F';
	fd->sym = name;
	fd->params = syms;
	fd->body = func;
	fd->ret = ret->nodetype;
	return (struct ast*)fd;
}

/* @function: callfn
 * @static
 * @private
 *
 * verify and evaluate a function.
 * 
 * @param {struct fncall*} f: name of the function.
 *
 * @returns void
*/

static int callfn(struct fncall *f)
{
	struct symbol *fn = f->sym; /* function name */
	struct symlist *sl; /* dummy arguments */
	struct ast *args = f->args; /* actual arguments */
	int *oldval, *newval; /* saved arg values */
	int v;
	int nargs;
	int i;
	if(!fn->func) /* NULL pointer - not declared function */
	{
		yyerror("call to undefined function", fn->name);
		return 0;
	}
	/* count the arguments */
	sl = fn->syms;
	for(nargs = 0; sl; sl = sl->next) nargs++;
	/* prepare to save them */
	oldval = (int*)malloc(nargs * sizeof(int));
	newval = (int*)malloc(nargs * sizeof(int));
	if(!oldval || !newval)
	{
		yyerror("Out of space in %s", fn->name);
		return 0;
	}
	/* evaluate the arguments */
	for(i = 0; i < nargs; i++) 
	{
		if(!args) /* do not passed all arguments to the function */ 
		{ 
			yyerror("too few args in call to %s", fn->name);
			free(oldval);
			free(newval);
			return 0;
		}
		if(args->nodetype == 'L')  /* if this is a list node */
		{
			newval[i] = eval(args->left);
			args = args->right;
		} 
		else /* if it's the end of the list */
		{ 
			newval[i] = eval(args);
			args = NULL;
		}
	}
	/* save old values of dummies, assign new ones */
	sl = fn->syms;
	for(i = 0; i < nargs; i++) {
		struct symbol *s = sl->sym;
		oldval[i] = s->value;
		s->value = newval[i];
		sl = sl->next;
	}
	free(newval);
	/* evaluate the function */
	v = eval(fn->func);
	/* put the real values of the dummies back */
	sl = fn->syms;
	for(i = 0; i < nargs; i++) {
		struct symbol *s = sl->sym;
		s->value = oldval[i];
		sl = sl->next;
		}
		free(oldval);
		return v;
}

/* @function: eval
 * 
 * evaluates the value of a AST.
 * 
 * @param {struct ast*} ast: which tree.
 *
 * @returns {int} evaluated value.
*/

int eval(struct ast *a)
{
	int v;
	if(!a)  /* NULL pointer */
	{
		yyerror("internal error, null eval");
		return 0;
	}
	switch(a->nodetype)
	{
		case 'K': /* constant */ 
			v = ((struct numval *)a)->number;
			break;
		
		case 'N': /* name reference */
			v = ((struct symref *)a)->sym->value;
			break;
		
		//case '=': /* assignment */
		//	v = ((struct symasgn *)a)->sym->value = eval(((struct symasgn *)a)->value);
		//	break;

		/* expressions */
		case '+': 
			v = eval(a->left) + eval(a->right);
			break;
		case '-': 
			v = eval(a->left) - eval(a->right); 
			break;
		case '*': 
			v = eval(a->left) * eval(a->right); 
			break;
		case '/': 
			v = eval(a->left) / eval(a->right); 
			break;
		
		/* comparisons */
		case '1': 
			v = (eval(a->left) > eval(a->right))? 1 : 0; 
			break;
		case '2': 
			v = (eval(a->left) < eval(a->right))? 1 : 0; 
			break;
		case '3': 
			v = (eval(a->left) != eval(a->right))? 1 : 0; 
			break;
		case '4': 
			v = (eval(a->left) == eval(a->right))? 1 : 0; 
			break;
		case '5': 
			v = (eval(a->left) >= eval(a->right))? 1 : 0; 
			break;
		case '6':
			 v = (eval(a->left) <= eval(a->right))? 1 : 0; 
			break;
		
		/* control flow */
		/* null expressions allowed in the grammar, so check for them */
		/* if/then/else */
		case 'I':
			if( eval( ((struct flow *)a)->condition) != 0) { /*check the condition*/
				if( ((struct flow *)a)->then_list) { /*the true branch*/
					v = eval( ((struct flow *)a)->then_list);
				} 
				else v = 0; /* a default value */
			}
			else
			{
				if( ((struct flow *)a)->else_list) { /*the false branch*/
					v = eval(((struct flow*)a)->else_list);
				} 
				else v = 0; /* a default value */
			}
			break;
		
		/* while/do */
		case 'W':
			v = 0; /* a default value */
			if( ((struct flow *)a)->then_list) {
				while( eval(((struct flow*)a)->condition) != 0) /*evaluate the condition*/
				v = eval(((struct flow *)a)->then_list); /*evaluate the target statements*/
			}
			break; /* value of last statement is value of while/do */

		/* list of statements */
		case 'L': 
			eval(a->left); 
			v = eval(a->right); 
			break;
		
		case 'F': 
			v = callfn((struct fncall*)a); 
			break;
		
		default: 
			printf("internal error: bad node %c\n", a->nodetype);
	}
	return v;
}

/* @function: astfree 
 * 
 * Free the alocated memory of the ast passed.
 * 
 * @param {struct ast*} ast
 *
 * @returns: void
*/

void treefree(struct ast *a)
{
	if(a)
	{
		switch(a->nodetype) {
	/* two subtrees */
		case '+':
		case '-':
		case '*':
		case '/':
		case '1': case '2': case '3': case '4': case '5': case '6':
		case 'L':
			treefree(a->right);
		/* one subtree */
		case 'F':
			treefree(a->left);
		/* no subtree */
		case 'K': case 'N': case 259: case 260: 
			break;
		case '=':
			free(((struct symasgn*)a)->value);
			break;
		/* up to three subtrees */
		case 'I': case 'W':
			free(((struct flow*)a)->condition);
			if(((struct flow *)a)->then_list) 
				treefree(((struct flow*)a)->then_list);
			if(((struct flow *)a)->else_list) 
				treefree(((struct flow*)a)->else_list);
			break;
		default: 
			printf("internal error: free bad node %c\n", a->nodetype);
	}
	free(a); /* always free the node itself */
	}
	
}

struct symbol* getSymbol(struct symbol *s, int index)
{
	if(!s)
	{
		return NULL;
	}
	struct symlist *aux;
	aux = s->syms->next;
	while(!aux && index > 0)
	{
		aux = aux->next;
		index--;
	}
	return aux->sym;
}


void printnode(struct ast *a)
{
	if(!a)  /* NULL pointer */
	{
		yyerror("internal error, null eval");
	}
	struct symref *sr;
	struct symbol *s;
	switch(a->nodetype)
	{
		case 'K': /* constant */ 
			printf("%d",((struct numval *)a)->number);
			break;
		
		case 'N': /* name reference */
			//printf("N");
			sr = (struct symref*)a;
			s = sr->sym;	
			printf("%s",s->name);
			if(sr->sym->length > 0)
			{
				printf("[%d]",sr->sym->length );
			}
			if(sr->sym->length == -1)
			{
				printf("[]");
			}
			if(a->left != NULL)
			{
				a->left = NULL;
			}
			break;
		
		case '=': /* assignment */
			printf("=");
			break;

		/* expressions */
		case '+': 
			printf("+");
			break;
		case '-': 
			printf("-"); 
			break;
		case '*': 
			printf("*"); 
			break;
		case '/': 
			printf("/"); 
			break;
		
		/* comparisons */
		case '1': 
			printf(">");
			break;
		case '2': 
			printf("<");
			break;
		case '3': 
			printf("!=");
			break;
		case '4': 
			printf("==");
			break;
		case '5': 
			printf(">=");
			break;
		case '6':
			 printf("<=");
			break;
		
		/* control flow */
		/* null expressions allowed in the grammar, so check for them */
		/* if/then/else */
		case 'I':
			printf("if");
			break;
		
		/* while/do */
		case 'W':
			printf("while");
			break; /* value of last statement is value of while/do */

		/* list of statements */
		case 'L': 
			//printf("L");
			break;
		
		case 'F': 
			if(((struct fndef*)a)->sym->name == NULL) printf("MEH\n");
			else printf("%s",((struct fndef*)a)->sym->name);
			break;
		
		case 'C':
			if(((struct fncall*)a)->sym->name == NULL) printf("MEH2\n");
			else printf("call %s",((struct fncall*)a)->sym->name);
			a->right = NULL;
			break;
		case 259:
			printf("int");
			a->left = NULL;
			a->right = NULL;
			break;
		case 260:
			printf("void");
			a->left = NULL;
			a->right = NULL;
			break;
		case 48:
			printf("int");
			break;
		default: 
			printf("internal error: bad node %c\n", a->nodetype);
			a->left = NULL;
			a->right = NULL;
	}
}


void printtree(struct ast *ast)
{
	if(ast != NULL)
	{	
		printnode(ast);
		if(ast->left != NULL)
		{
			printf("(");
			printtree(ast->left);
			printf(")");
		}
		if(ast->right != NULL)
		{
			printf("(");
			printtree(ast->right);
			printf(")");
		}
	}
}

void printprog(struct ast *ast)
{
	while(ast != NULL)
	{
		printtree(ast->left);
		ast = ast->right;
	}
}

struct ast* newtype(int type)
{
	struct ast* a = (struct ast*)malloc(sizeof(struct ast));
	if(a) a->nodetype = type;
	return a;
}

struct ast* astlist(struct ast *list, struct ast *new)
{
	struct ast *aux;
	aux = list;
	while(aux->right != NULL)
	{
		aux = aux->right;
	}
	aux->right = new;
	return list;
}